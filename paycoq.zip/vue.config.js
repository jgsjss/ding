module.exports = {

    lintOnSave: false

}