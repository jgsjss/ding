<template>
  <!-- 메뉴모달 컴포넌트 -->
  <MenuModal />

  <!-- 좌측 네브바 메뉴 -->
  <div class="container">
    <ul class="nav flex-column">
      <li class="nav-item">
        <i class="xi-cloud-o"></i>
        <router-link to="/main"><p class="nav-link active" aria-current="page">로고</p></router-link>
      </li>
      <li class="nav-item">
        <i class="xi-cloud-o"></i>
        <router-link to="/menumanagement"><p class="nav-link">메뉴관리</p></router-link>
      </li>
      <li class="nav-item">
        <i class="xi-cloud-o"></i>
        <router-link to="/ordermanagement"><p class="nav-link">매출관리</p></router-link>
      </li>
      <li class="nav-item">
        <i class="xi-cloud-o"></i>
        <router-link to="/staffmanagement"><p class="nav-link">직원관리</p></router-link>
      </li>
      <li class="nav-item">
        <i class="xi-cloud-o"></i>
        <router-link to="/operationmanagement"><p class="nav-link">운영관리</p></router-link>
      </li>
      <li class="nav-item">
        <i class="xi-cloud-o"></i>
        <router-link to="/discountcode"><p class="nav-link">할인코드</p></router-link>
      </li>
      <li class="nav-item">
        <i class="xi-cloud-o"></i>
        <a class="nav-link" href="">img</a>
      </li>
    </ul>
  </div>
  <router-view> </router-view>



</template>
<script>
import MenuModal from './components/MenuModal.vue'


export default {
  data(){
    return{

    }
  },
  components: {
    MenuModal
  },
  methods: {

  },
  created(){

  },
  mounted(){
  },
  watch: {

  },

}
</script>

<style scoped>
.container {
  max-width:768px;
  padding:30px 15px;
}
.flex-column {
  float:left;
  background:#dcd4e3;
}
.nav-item {
  text-align: center;
  padding:15px 0;
}
.nav-item > .xi-cloud-o {
  border:1px dashed #c6a6e2;
  border-radius: 100%;
  padding:5px;
  color:#fff;
}
.nav-link {
  color:#997fb5;
  text-decoration: none;
}
.nav-link:hover {
  color:#997fb5;
  text-decoration: none;
}
</style>
