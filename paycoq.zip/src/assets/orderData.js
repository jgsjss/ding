export default
    [
        {
            orderNo : 1,
            menu : 'capuccino',
            isCompleted : true,
            isCanceled : false,

        },

        {
            orderNo : 2,
            menu : 'capuccino',
            isCompleted : true,
            isCanceled : false,
        },

        {
            orderNo :3,
            menu : 'capuccino',
            isCompleted : true,
            isCanceled : false,
        },

        {
            orderNo : 4,
            menu : 'capuccino',
            isCompleted : true,
            isCanceled : false,
        },

        {
            orderNo : 5,
            menu : 'capuccino',
            isCompleted : false,
            isCanceled : false,
        },

        {
            orderNo : 6,
            menu : 'capuccino',
            isCompleted : false,
            isCanceled : false,
        },
        {
            orderNo : 7,
            menu : 'capuccino',
            isCompleted : false,
            isCanceled : false,
        },
        {
            orderNo : 8,
            menu : 'capuccino',
            isCompleted : false,
            isCanceled : false,
        },
        {
            orderNo : 9,
            menu : 'capuccino',
            isCompleted : false,
            isCanceled : false,
        },
        {
            orderNo : 10,
            menu : 'capuccino',
            isCompleted : false,
            isCanceled : false,
        },
        {
            orderNo : 11,
            menu : 'capuccino',
            isCompleted : false,
            isCanceled : false,
        },
        {
            orderNo : 12,
            menu : 'capuccino',
            isCompleted : false,
            isCanceled : false,
        },

]
