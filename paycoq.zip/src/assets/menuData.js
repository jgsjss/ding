export default [
    {
        name : '진짜 진한 바닐라 리얼 딥',
        price: 12300,
        isSoldOut : false,
        isHidden : false,
        categories : '메뉴'

    },
    {
        name :  '진짜 생초코 크레이프',
        price: 12000,
        isSoldOut : false,
        isHidden : false,
        categories : '메뉴'

    },
    {
        name : '코코넛 라떼',
        price: 13500,
        isSoldOut : false,
        isHidden : false,
        categories : '메뉴'

    },
    {
        name : '코코넛 콜드브루',
        price: 13500,
        isSoldOut : true,
        isHidden : false,
        categories : '메뉴'

    },
    {
        name : '진짜 리얼 자두 에이드',
        price: 13500,
        isSoldOut : true,
        isHidden : false,
        categories : '메뉴'

    },
    {
        name : '히비스커스',
        price: 13500,
        isSoldOut : false,
        isHidden : true,
        categories : '메뉴'

    },
    {
        name : '진짜 딩동 커피',
        price: 13500,
        isSoldOut: true,
        isHidden: false,
        categories : '메뉴'

    }
]
