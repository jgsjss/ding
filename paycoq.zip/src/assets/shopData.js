export default [
  {
    shopName: '딩동 센텀점',
    isClosed: false,
  },
  {
    shopName: '딩동 광안점',
    isClosed: false,
  },
  {
    shopName: '딩동 달맞이점',
    isClosed: false,
  },
  {
    shopName: '딩동 수영점',
    isClosed: false,
  },
  {
    shopName: '딩동 연산점',
    isClosed: false,
  },
  {
    shopName: '딩동 개금점',
    isClosed: false,
  },
  {
    shopName: '딩동 가야점',
    isClosed: false,
  },
  {
    shopName: '딩동 주례점',
    isClosed: false,
  },
  {
    shopName: '딩동 서면1호점',
    isClosed: false,
  },
  {
    shopName: '딩동 서면2호점',
    isClosed: false,
  },
  {
    shopName: '딩동 당감점',
    isClosed: false,
  },

]
